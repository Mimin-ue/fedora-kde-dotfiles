# Sólo se carga en este perfil: no cambia Fish ni Bash de las demás terminales.
set -e NO_COLOR
set -g fish_greeting
set -g fish_color_command 78a8c6
set -g fish_color_param c9ced7
set -g fish_color_error e77980
set -g fish_color_quote 9fbb82
function fish_greeting
end
function fish_prompt
    set -l previous_status $status
    set -l left "~ $USER   fish"
    set -l elapsed 0
    if set -q CMD_DURATION
        set elapsed (math --scale=3 "$CMD_DURATION / 1000")
    end
    set -l right "$elapsed"s"  ┊ "(date '+%A %H:%M')
    set -l padding (math $COLUMNS - (string length -- $left) - (string length -- $right))
    set_color 8c97aa
    if test $padding -ge 2
        printf '%s%*s%s\n' "$left" $padding '' "$right"
    else
        printf '%s\n' "$left"
    end
    set_color 78a8c6
    printf '~ '
    set_color b7c6db
    printf ' %s ' (prompt_pwd)
    if test $previous_status -ne 0
        set_color e77980
    else
        set_color c9ced7
    end
    printf '❯ '
    set_color normal
end
function fish_right_prompt
end
function venomfetch
    command fastfetch --pipe false --config @HOME@/.config/kitty/venom/fastfetch.jsonc
end
if status is-interactive
    set_color c9ced7
    printf '❯ fastfetch\n\n'
    venomfetch
end
