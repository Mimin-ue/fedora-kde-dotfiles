"""Espectro de cinco bandas del monitor de salida de audio, para el panel de KDE."""
from pathlib import Path
import json,signal,sys
from PySide6.QtCore import QCoreApplication,QObject,QProcess,QTimer,Property,ClassInfo,QMetaType
from PySide6.QtDBus import QDBusConnection,QDBusMessage,QDBusArgument
IFACE='local.mimin.AudioSpectrum'
@ClassInfo(**{'D-Bus Interface':IFACE})
class Spectrum(QObject):
    def __init__(self,bus):
        super().__init__();self.bus=bus;self.value='[0,0,0,0,0]';self.buffer=b''
        self.proc=QProcess(self);self.proc.setProgram('/usr/bin/cava')
        self.proc.setArguments(['-p',str(Path(__file__).with_name('cava.conf'))])
        self.proc.readyReadStandardOutput.connect(self.read)
        self.proc.readyReadStandardError.connect(lambda:sys.stderr.write(bytes(self.proc.readAllStandardError()).decode(errors='replace')))
        self.proc.finished.connect(lambda code,status:QCoreApplication.exit(1))
    @Property(str)
    def Levels(self):return self.value
    def read(self):
        self.buffer+=bytes(self.proc.readAllStandardOutput())
        frames=self.buffer.split(b'\n');self.buffer=frames.pop()
        if not frames:return
        try:
            values=[max(0,min(100,int(x)))/100 for x in frames[-1].strip(b';\r').split(b';')[:5]]
            if len(values)!=5:return
            data=json.dumps(values,separators=(',',':'))
        except ValueError:return
        if data==self.value:return
        self.value=data
        invalidated=QDBusArgument();invalidated.beginArray(QMetaType.Type.QString);invalidated.endArray()
        msg=QDBusMessage.createSignal('/Spectrum','org.freedesktop.DBus.Properties','PropertiesChanged')
        msg.setArguments([IFACE,{'Levels':data},invalidated]);self.bus.send(msg)
    def stop(self):
        self.proc.finished.disconnect();self.proc.terminate()
        if not self.proc.waitForFinished(1500):self.proc.kill()
app=QCoreApplication(sys.argv);bus=QDBusConnection.sessionBus()
if not bus.registerService(IFACE):raise SystemExit('El espectro ya está iniciado o el bus no está disponible.')
bridge=Spectrum(bus)
assert bus.registerObject('/Spectrum',bridge,QDBusConnection.RegisterOption.ExportAllProperties)
app.aboutToQuit.connect(bridge.stop)
signal.signal(signal.SIGTERM,lambda *_:app.quit());signal.signal(signal.SIGINT,lambda *_:app.quit())
heartbeat=QTimer();heartbeat.timeout.connect(lambda:None);heartbeat.start(500)
bridge.proc.start();sys.exit(app.exec())
