// SPDX-License-Identifier: GPL-2.0-or-later
// API nativa de KWin; patrón de ciclo de vida basado en el efecto Squash de KDE.
const softFade = {
    connectWindow(w) {
        w.minimizedChanged.connect(() => {
            if (effects.hasActiveFullScreenEffect || !w.normalWindow || w.popupWindow) return;
            if (w.miminFadeAnimation) cancel(w.miminFadeAnimation);
            w.setData(Effect.WindowForceBlurRole, true);
            w.miminFadeAnimation = animate({
                window:w,
                duration:animationTime(w.minimized ? 210 : 160),
                curve:QEasingCurve.OutCubic,
                keepAlive:false,
                animations:[{type:Effect.Opacity,from:w.minimized?1.0:0.0,to:w.minimized?0.0:1.0}]
            });
        });
    },
    init() {
        effects.windowAdded.connect(w => this.connectWindow(w));
        for (const w of effects.stackingOrder) this.connectWindow(w);
        effect.animationEnded.connect(w => {w.setData(Effect.WindowForceBlurRole,null);delete w.miminFadeAnimation;});
    }
};
softFade.init();
