import QtQuick

Item {
    id: marquee
    property string fullText: ""
    property color textColor: "#a9b8d5"
    readonly property bool overflowing: width > 0 && firstLabel.implicitWidth > width
    readonly property real cycleDistance: firstLabel.implicitWidth + 36
    clip: true

    function syncAnimation() {
        movement.stop();
        ticker.x = 0;
        if (overflowing && visible) movement.start();
    }
    onFullTextChanged: Qt.callLater(syncAnimation)
    onWidthChanged: Qt.callLater(syncAnimation)
    onCycleDistanceChanged: Qt.callLater(syncAnimation)
    onVisibleChanged: Qt.callLater(syncAnimation)
    Component.onCompleted: Qt.callLater(syncAnimation)

    Row {
        id: ticker
        height: marquee.height
        spacing: 36
        Text {
            id: firstLabel
            text: marquee.fullText
            height: marquee.height
            color: marquee.textColor
            font.family: "Noto Sans Mono"
            font.pixelSize: 13
            wrapMode: Text.NoWrap
            verticalAlignment: Text.AlignVCenter
        }
        Text {
            text: marquee.fullText
            visible: marquee.overflowing
            height: marquee.height
            color: marquee.textColor
            font: firstLabel.font
            wrapMode: Text.NoWrap
            verticalAlignment: Text.AlignVCenter
        }
    }
    NumberAnimation {
        id: movement
        target: ticker
        property: "x"
        from: 0
        to: -marquee.cycleDistance
        duration: Math.max(1000, Math.round(marquee.cycleDistance / 28 * 1000))
        loops: Animation.Infinite
        easing.type: Easing.Linear
    }
}
