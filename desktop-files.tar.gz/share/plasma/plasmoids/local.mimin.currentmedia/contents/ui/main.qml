import QtQuick
import QtQuick.Layouts
import org.kde.plasma.plasmoid
import org.kde.plasma.core as PlasmaCore
import org.kde.kirigami as Kirigami
import org.kde.plasma.private.mpris as Mpris
import org.kde.plasma.workspace.dbus as DBus
PlasmoidItem {
 id:root
 Plasmoid.backgroundHints: PlasmaCore.Types.NoBackground
 Mpris.Mpris2Model { id:players }
 DBus.Properties { id:spectrum; service:"local.mimin.AudioSpectrum";path:"/Spectrum";iface:"local.mimin.AudioSpectrum" }
 readonly property var audioLevels: {
  try { return JSON.parse(spectrum.properties.Levels || "[0,0,0,0,0]"); }
  catch(e) { return [0,0,0,0,0]; }
 }
 readonly property var player: players.currentPlayer
 readonly property bool hasPlayer: player!=null
 readonly property string title: hasPlayer ? (player.track || player.identity) : "Sin reproducción"
 readonly property string artist: hasPlayer ? player.artist : "Abre Spotify o reproduce música en el navegador"
 Layout.minimumWidth:220
 Layout.preferredWidth:260
 Layout.maximumWidth:260
 preferredRepresentation: fullRepresentation
 toolTipMainText: title
 toolTipSubText: artist+"
Clic: reproducir/pausar · rueda: anterior/siguiente · clic central: abrir reproductor"
 fullRepresentation: Item {
  RowLayout {
   anchors.fill:parent;anchors.leftMargin:7;anchors.rightMargin:7;spacing:7
   Kirigami.Icon { source:root.hasPlayer?(root.player.iconName||"audio-x-generic"):"audio-x-generic";Layout.preferredWidth:16;Layout.preferredHeight:16 }
   ScrollingTrack {
    Layout.fillWidth:true;Layout.minimumWidth:0;Layout.fillHeight:true
    fullText:root.hasPlayer&&root.artist?root.artist+" — "+root.title:root.title
   }
   Item {
    Layout.preferredWidth:30;Layout.preferredHeight:18
    Row {
     anchors.centerIn:parent;spacing:4
     Repeater {
      model:5
      Rectangle {
       required property int index
       width:2;radius:1;anchors.verticalCenter:parent.verticalCenter
       height:2+Math.round(14*(root.audioLevels[index]||0))
       color:"#a9b8d5"
       Behavior on height { NumberAnimation {duration:75;easing.type:Easing.OutCubic} }
      }
     }
    }
   }
  }
  MouseArea {
   anchors.fill:parent;acceptedButtons:Qt.LeftButton|Qt.MiddleButton
   cursorShape:Qt.PointingHandCursor
   onClicked:mouse=>{if(!root.hasPlayer)return;if(mouse.button===Qt.MiddleButton){if(root.player.canRaise)root.player.Raise();}else if(root.player.canControl)root.player.PlayPause();}
   onWheel:wheel=>{if(!root.hasPlayer)return;if(wheel.angleDelta.y>0&&root.player.canGoNext)root.player.Next();else if(root.player.canGoPrevious)root.player.Previous();}
  }
 }
}
