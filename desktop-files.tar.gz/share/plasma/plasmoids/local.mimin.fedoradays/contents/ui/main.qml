import QtQuick
import QtQuick.Layouts
import org.kde.plasma.plasmoid
import org.kde.plasma.core as PlasmaCore
import org.kde.kirigami as Kirigami
PlasmoidItem {
 id: root
 Plasmoid.backgroundHints: PlasmaCore.Types.NoBackground
 property date now: new Date()
 readonly property int days: Math.max(0,Math.floor((Date.UTC(now.getFullYear(),now.getMonth(),now.getDate())-Date.UTC(2026,10,3))/86400000))
 Layout.minimumWidth: 96
 Layout.preferredWidth: 96
 Layout.maximumWidth: 96
 preferredRepresentation: fullRepresentation
 toolTipMainText: "Días con Fedora"
 toolTipSubText: "Instalado el 3 de noviembre de 2026"
 Timer { interval:60000; running:true; repeat:true; onTriggered:root.now=new Date() }
 fullRepresentation: Item {
  Text { anchors.centerIn:parent; text:"♥ "+root.days+(root.days===1?" día":" días");color:"#a9b8d5";font.family:"Noto Sans Mono";font.pixelSize:13 }
 }
}
