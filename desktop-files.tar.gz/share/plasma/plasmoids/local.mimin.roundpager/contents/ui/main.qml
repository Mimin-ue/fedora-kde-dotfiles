import QtQuick
import QtQuick.Layouts
import org.kde.plasma.plasmoid
import org.kde.plasma.core as PlasmaCore
import org.kde.taskmanager as TaskManager
import org.kde.plasma.plasma5support as Plasma5Support
PlasmoidItem {
 id:root
 Plasmoid.backgroundHints: PlasmaCore.Types.NoBackground
 TaskManager.VirtualDesktopInfo { id:desktops }
 Plasma5Support.DataSource {
  id:commands;engine:"executable"
  onNewData:(sourceName,data)=>disconnectSource(sourceName)
 }
 Layout.minimumWidth:130
 Layout.preferredWidth:130
 Layout.maximumWidth:130
 toolTipMainText:"Escritorios virtuales"
 toolTipSubText:"Clic en un círculo para cambiar de escritorio"
 preferredRepresentation:fullRepresentation
 fullRepresentation:Item {
  Row {
   anchors.centerIn:parent;spacing:12
   Repeater {
    model:desktops.desktopIds
    Rectangle {
     required property var modelData
     readonly property bool active:desktops.currentDesktop===modelData
     width:active?27:10;height:10;radius:5;anchors.verticalCenter:parent.verticalCenter
     color:active?"#859fcb":"transparent";border.width:1;border.color:active?"#859fcb":"#718098"
     Behavior on width { NumberAnimation {duration:160;easing.type:Easing.InOutQuad} }
     MouseArea {
      anchors.fill:parent;anchors.margins:-5;cursorShape:Qt.PointingHandCursor
      onClicked:{var id=String(parent.modelData);if(/^[0-9a-f-]+$/i.test(id))commands.connectSource("qdbus-qt6 org.kde.KWin /VirtualDesktopManager org.kde.KWin.VirtualDesktopManager.current "+id);}
     }
    }
   }
  }
 }
}
